# Memory Index

- [Spike discipline and joint review](spike-discipline-and-joint-review.md) — minimal paid spikes, one variable each; visual/model decisions locked only after joint evidence review
