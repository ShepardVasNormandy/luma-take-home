---
name: spike-discipline-and-joint-review
description: "Enzo's rules for spikes and evidence-based decisions — minimal paid experiments, one variable at a time, and visual/model choices reviewed jointly before locking"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c0a60da1-8972-4e9d-8603-7e4e46e3b8aa
  modified: 2026-09-01T11:15:50.606Z
---

Spikes must collapse uncertainty with the minimum paid calls (4–6, not 15–20), changing one variable per experiment — never a combinatorial matrix. Don't claim to measure things the spike can't (e.g. approval rates without the real approver).

**Why:** "We're trying to collapse uncertainty, not produce statistically rigorous image evals in a one-day take-home." Also budget discipline mirrors the product's own spend-gating values.

**How to apply:** Before running paid experiments, list the specific questions each generation answers. For model/visual quality decisions: run, preserve full evidence (inputs, exact prompts, params, outputs, latency, cost, IDs), present side-by-side with observations clearly separated from the user's, give a recommendation, but never lock the choice before the user has reviewed the evidence themselves. Related: [[caveman-mode-preference]].
